package in.capgemini.OnlineFoodDelivery;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OfdtoolapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(OfdtoolapiApplication.class, args);
	}

}
